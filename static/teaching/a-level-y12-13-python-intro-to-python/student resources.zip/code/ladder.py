# ladder.py : the Function Ladder (Intro to Python)
# Work down the file one rung at a time. Press F5 to run the file, then test each
# function in the console (bottom right) with the test chip from your worksheet.
# Replace every "pass" and every TODO with your own code.


# ---- Rung 1: no input ------------------------------------------------------
# lucky() gives back the number 7.   Test chip:  lucky()  ->  7
def lucky():
    return 7


# ---- Rung 2: one input -----------------------------------------------------
# add_one(x) gives back x plus 1.    Test chip:  add_one(5)  ->  6
def add_one(x):
    pass  # TODO: return something made from x

# Your turn: write your own one-input function here (any name, any maths).



# ---- Rung 3: what is return FOR? -------------------------------------------
# Type this in exactly as it is, run the file, then call hello() in the console.
# Write down what happens. Then think about why.



# ---- Rung 4: two inputs ----------------------------------------------------
# average(a, b) gives back the average of a and b.   Test chip:  average(3, 5)  ->  4.0
def average(a, b):
    pass  # TODO: add them up, then divide by 2 (careful with brackets)


# product(a, b) gives back a times b.   Test chip:  product(6, 7)  ->  42
def product(a, b):
    pass  # TODO


# ---- Rung 5: the four functions the calculator needs ------------------------
# The names must be EXACTLY add, subtract, multiply, divide.
# Test chips:  add(2, 3) -> 5    subtract(10, 4) -> 6    multiply(6, 7) -> 42    divide(9, 2) -> 4.5
def add(a, b):
    pass  # TODO

def subtract(a, b):
    pass  # TODO

def multiply(a, b):
    pass  # TODO

def divide(a, b):
    pass  # TODO


# ---- Rung 6: calls inside calls --------------------------------------------
# Nothing to write. In the console, guess first, then run:
#   add(multiply(3, 4), 2)
#   divide(add(6, 8), 2)


# ---- Rung 7: stretch -------------------------------------------------------
# power(a, b) gives back a to the power b.   Test chip:  power(2, 10)  ->  1024
# Hint: a ** b means multiply a by itself b times.
