# calculator.py : the Calculator (Intro to Python)
# Variables + functions + if statements, together.
# Work through the steps in order. Press F5 to run the file.


# ---- Step 1: the four functions ---------------------------------------------
# Paste your four ladder functions here: add, subtract, multiply, divide.
# (Copy them from ladder.py. The names must be exactly the same.)



# ---- Step 2: ask the user ---------------------------------------------------
# input() always gives back text. float() turns text into a number.
operation = ""   # TODO: ask "Pick: + - * / " with input()
num1 = 0         # TODO: ask "First number: " with input(), wrapped in float()
num2 = 0         # TODO: ask "Second number: " with input(), wrapped in float()


# ---- Step 3: decide what to do ----------------------------------------------
result = 0
# TODO: if operation is "+", result is add(num1, num2)
#       elif operation is "-", ... and so on for "*" and "/"
#       (use == to compare, and remember the colon and the indent)


# ---- Step 4: show the result ------------------------------------------------
# TODO: print "Answer: " followed by the result.
# Hint: an f-string drops a variable into text with { }.


# ---- Stretch ----------------------------------------------------------------
# Add power(a, b) to ladder.py and to this file, then add a new elif for "**".
