# cow_message_starter.py
# The cow message puzzle: 37 photos each hide ONE letter. Decode them all with Python.
#
# THE RULE (the same for every photo):
#   1. open the photo
#   2. add up every RED value in it (this is the total)
#   3. take the total % 26      (a number from 0 to 25)
#   4. use that number to pick a letter: A is 0, B is 1, C is 2 ... Z is 25
#
# SET UP: keep this file in the SAME folder as cow-demo.jpg and the cow_message folder.
# Run it with the green triangle (or F5). Do the STEPS in order and test each one before the next.
# Stuck? Each STEP has two hints. Try it yourself first, then read Hint 1, then Hint 2.

import numpy as np
from PIL import Image

ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"     # A is 0, B is 1, ... Z is 25


# ---------- GIVEN: you do not need to change this function ----------
def image_path(number):
    # image_path(1) gives "cow_message/01.png", image_path(12) gives "cow_message/12.png"
    return "cow_message/" + str(number).zfill(2) + ".png"


# ---------- STEP 1: look at a photo (run this and read the output) ----------
# cow-demo.jpg is our 320 x 320 practice photo. The 37 puzzle photos are 640 x 640.
# The same code works on both, so practise on the demo first.
img = Image.open("cow-demo.jpg")
pixels = np.array(img)
print("size:", img.size)
print("shape:", pixels.shape)
print("first pixel:", pixels[0, 0])


# ---------- STEP 2 (TODO): add up all the red in ONE photo ----------
def total_red(path):
    img = Image.open(path)
    pixels = np.array(img)

    # TODO: get just the red channel
    # TODO: add up every red value in it
    # TODO: return that total

    return 0

    # Hint 1: you already got one channel in Task 4, and you already counted with .sum() in Task 7.
    #         The function must RETURN the answer, not just print it.
    # Hint 2: red = pixels[:, :, ___]
    #         total = red.___()
    #         return ___


# Test it. It should print 10218857
print(total_red("cow-demo.jpg"))


# ---------- STEP 3 (TODO): turn a photo into ONE letter ----------
def letter_for(path):
    # TODO: 1. get the red total for this photo (you wrote a function for this!)
    #       2. take it % 26
    #       3. use that number to pick a letter from ALPHABET
    #       4. return the letter

    return ""

    # Hint 1: call the function you wrote: total_red(path). Then % gives the position (0 to 25).
    #         Square brackets pick the letter: ALPHABET[2] is "C".
    # Hint 2: total = ___(path)
    #         position = total % ___
    #         letter = ALPHABET[___]
    #         return ___


# Test it. It should print Z
print(letter_for("cow-demo.jpg"))


# ---------- STEP 4 (TODO): decode the WHOLE message ----------
def decode_message():
    message = ""       # the message we are building. It starts empty.

    # TODO: for each number from 1 to 37
    #   1. find the photo:  image_path(number)
    #   2. work out its letter (you already wrote a function for this!)
    #   3. stick the letter on the end of message:  message += letter

    return message

    # Hint 1: for number in range(1, 38): counts from 1 to 37 (it stops before 38).
    #         Inside the loop: get the path, get the letter, add the letter with +=
    # Hint 2: for number in range(1, 38):
    #             path = image_path(number)
    #             letter = ___(path)
    #             message += ___


# Run it (take the # off the next line). It can take a few seconds.
# Does it read like English? Then it worked. If it is gibberish, check STEP 2 and STEP 3 again.
# print(decode_message())


# ---------- STRETCH: finished early? ----------
# 1. A different channel: add up the GREEN values (channel 1) or BLUE values (channel 2) instead.
#    Copy your functions, change the 0, and see what message you get.
# 2. One function for any channel: write total_channel(path, channel) so you do not need to copy your code.
